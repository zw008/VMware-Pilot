"""VMware Pilot — multi-step workflow orchestration with approval gates."""

__version__ = "0.1.0"
